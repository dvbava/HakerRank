#!/usr/bin/env pwsh

# Unit Test Runner Script for ApprovalAPI
# This script runs all unit tests and generates coverage reports

Write-Host "Starting Unit Tests for ApprovalAPI..." -ForegroundColor Green

# Navigate to the test project directory
Set-Location "ApprovalAPI.Tests"

# Clean previous test results
if (Test-Path "TestResults") {
    Remove-Item "TestResults" -Recurse -Force
}

# Run tests with coverage
Write-Host "Running tests with coverage..." -ForegroundColor Yellow
dotnet test --collect:"XPlat Code Coverage" --results-directory TestResults --logger "console;verbosity=detailed"

# Check if tests passed
if ($LASTEXITCODE -eq 0) {
    Write-Host "All tests passed successfully!" -ForegroundColor Green
} else {
    Write-Host "Some tests failed. Please check the output above." -ForegroundColor Red
    exit 1
}

# Generate coverage report
Write-Host "Generating coverage report..." -ForegroundColor Yellow
$coverageFile = Get-ChildItem -Path "TestResults" -Filter "*.cobertura.xml" -Recurse | Select-Object -First 1

if ($coverageFile) {
    Write-Host "Coverage report generated: $($coverageFile.FullName)" -ForegroundColor Green
    
    # Display coverage summary
    Write-Host "`nCoverage Summary:" -ForegroundColor Cyan
    Write-Host "=================" -ForegroundColor Cyan
    
    # You can add more detailed coverage analysis here if needed
    Write-Host "Coverage report saved to: $($coverageFile.FullName)" -ForegroundColor White
} else {
    Write-Host "No coverage report found." -ForegroundColor Yellow
}

# Return to original directory
Set-Location ".."

Write-Host "`nTest execution completed!" -ForegroundColor Green 