using Provenance.Services.Data.ApprovalManager.Services;
using Provenance.Services.Data.ApprovalManager.Data;
using Microsoft.EntityFrameworkCore;
using HotChocolate.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "Generic Approval API",
        Version = "v1",
        Description = "A generic REST API for handling approval workflows"
    });
});

// Add Entity Framework
builder.Services.AddDbContext<ApprovalDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Configure SMTP Settings
builder.Services.Configure<Provenance.Services.Data.ApprovalManager.Models.SmtpSettings>(
    builder.Configuration.GetSection("Smtp"));

// Register services
builder.Services.AddScoped<IApprovalService, ApprovalService>();
builder.Services.AddScoped<Provenance.Services.Data.ApprovalManager.Services.Email.IEmailService, Provenance.Services.Data.ApprovalManager.Services.Email.EmailService>();
builder.Services.AddScoped<IConfigurationService, ConfigurationService>();

// Add GraphQL
builder.Services
    .AddGraphQLServer()
    .AddQueryType()
    .AddMutationType()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.ApprovalRequestType>()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.ApproverStatusType>()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.ChannelStatusType>()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.CreateApprovalRequestInputType>()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.ApproverInputType>()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.UpdateApprovalRequestInputType>()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.ApproveRequestInputType>()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.RejectRequestInputType>()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.CommentRequestInputType>()
    .AddType<Provenance.Services.Data.ApprovalManager.GraphQL.Types.CancelRequestInputType>()
    .AddInMemorySubscriptions();

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Approval API V1");
        c.RoutePrefix = string.Empty; // Serve Swagger UI at root
    });
}

app.UseHttpsRedirection();
app.UseCors("AllowAll");
app.UseAuthorization();
app.MapControllers();

// Map GraphQL endpoint
app.MapGraphQL();

app.Run();
