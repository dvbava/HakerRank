# GraphQL Test Queries

These queries can be used to test the GraphQL functionality. You can run them in the GraphQL Playground at `/graphql` or using any GraphQL client.

## Test Queries

### 1. Get All Approval Requests

```graphql
query {
  approvalRequests {
    primaryGuid
    title
    description
    status
    requesterId
    requesterName
    createdAt
    priority
  }
}
```

### 2. Get Pending Requests Only

```graphql
query {
  approvalRequests(status: PENDING) {
    primaryGuid
    title
    description
    status
    requesterId
    createdAt
  }
}
```

### 3. Get Requests by Type

```graphql
query {
  approvalRequests(requestType: "Vacation") {
    primaryGuid
    title
    description
    status
    requesterId
    createdAt
  }
}
```

### 4. Get Requests by Requester

```graphql
query {
  approvalRequests(requesterId: "user123") {
    primaryGuid
    title
    description
    status
    createdAt
  }
}
```

### 5. Get Pending Approvals for User

```graphql
query {
  pendingApprovalsForUser(userEmail: "manager@company.com") {
    primaryGuid
    title
    description
    requesterId
    requesterName
    createdAt
    priority
  }
}
```

### 6. Get My Requests

```graphql
query {
  myRequests(userId: "user123") {
    primaryGuid
    title
    description
    status
    createdAt
    priority
  }
}
```

## Test Mutations

### 1. Create Approval Request

```graphql
mutation {
  createApprovalRequest(input: {
    requestType: "Vacation"
    title: "Summer Vacation Request"
    description: "Annual leave request for summer vacation"
    requesterId: "user123"
    requesterName: "John Doe"
    requesterEmail: "john.doe@company.com"
    priority: 2
    approvers: [
      {
        approverEmail: "manager@company.com"
      }
    ]
  }) {
    primaryGuid
    title
    description
    status
    requesterId
    requesterName
    createdAt
  }
}
```

### 2. Create Another Request (for testing)

```graphql
mutation {
  createApprovalRequest(input: {
    requestType: "Equipment"
    title: "New Laptop Request"
    description: "Request for new development laptop"
    requesterId: "user456"
    requesterName: "Jane Smith"
    requesterEmail: "jane.smith@company.com"
    priority: 3
    approvers: [
      {
        approverEmail: "manager@company.com"
      },
      {
        approverEmail: "it@company.com"
      }
    ]
  }) {
    primaryGuid
    title
    description
    status
    requesterId
    requesterName
    createdAt
  }
}
```

### 3. Approve Request (replace {requestId} with actual ID)

```graphql
mutation {
  approveRequest(
    primaryGuid: "{requestId}"
    input: {
      approverEmail: "manager@company.com"
      comments: "Approved - enjoy your vacation!"
    }
  ) {
    primaryGuid
    status
    approvedBy
    approvedAt
    comments
  }
}
```

### 4. Reject Request (replace {requestId} with actual ID)

```graphql
mutation {
  rejectRequest(
    primaryGuid: "{requestId}"
    input: {
      rejectorEmail: "manager@company.com"
      rejectionReason: "Insufficient notice period"
      comments: "Please submit at least 2 weeks in advance"
    }
  ) {
    primaryGuid
    status
    rejectedBy
    rejectedAt
    rejectionReason
    comments
  }
}
```

### 5. Comment on Request (replace {requestId} with actual ID)

```graphql
mutation {
  commentOnRequest(
    primaryGuid: "{requestId}"
    input: {
      commenterId: "user123"
      comments: "Additional context: This is for a family vacation that was planned months ago."
    }
  ) {
    primaryGuid
    comments
  }
}
```

### 6. Cancel Request (replace {requestId} with actual ID)

```graphql
mutation {
  cancelRequest(
    primaryGuid: "{requestId}"
    input: {
      cancellerId: "user123"
      reason: "Plans changed - no longer needed"
    }
  ) {
    primaryGuid
    status
  }
}
```

## Testing Workflow

1. **Start the application**: Run the API and navigate to `/graphql`
2. **Create test data**: Use the create mutations to add some test requests
3. **Query the data**: Use the query operations to retrieve and filter requests
4. **Test actions**: Use the approve/reject/comment/cancel mutations to test workflow
5. **Verify results**: Query again to see the updated status

## Expected Results

- **Create**: Should return the created request with a new `primaryGuid`
- **Query**: Should return existing requests based on filters
- **Approve**: Should change status to `APPROVED` and set `approvedBy`/`approvedAt`
- **Reject**: Should change status to `REJECTED` and set `rejectedBy`/`rejectedAt`
- **Comment**: Should update the `comments` field
- **Cancel**: Should change status to `CANCELLED`
- **Delete**: Should return `true` if successful, `false` if not found 