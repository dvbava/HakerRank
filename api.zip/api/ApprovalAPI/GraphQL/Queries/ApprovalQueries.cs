using HotChocolate;
using HotChocolate.Types;
using Provenance.Services.Data.ApprovalManager.Models;
using Provenance.Services.Data.ApprovalManager.Models.DTOs;
using Provenance.Services.Data.ApprovalManager.Services;

namespace Provenance.Services.Data.ApprovalManager.GraphQL.Queries
{
    [ExtendObjectType("Query")]
    public class ApprovalQueries
    {
        /// <summary>
        /// Get a specific approval request by ID
        /// </summary>
        public async Task<ApprovalRequestResponseDto?> GetApprovalRequest(
            [Service] IApprovalService approvalService,
            Guid primaryGuid)
        {
            try
            {
                return await approvalService.GetApprovalRequestAsync(primaryGuid);
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
        }

        /// <summary>
        /// Get all approval requests with optional filtering
        /// </summary>
        public async Task<IEnumerable<ApprovalRequestResponseDto>> GetApprovalRequests(
            [Service] IApprovalService approvalService,
            string? requestType = null,
            ApprovalStatus? status = null,
            string? requesterId = null)
        {
            try
            {
                return await approvalService.GetApprovalRequestsAsync(requestType, status, requesterId);
            }
            catch (Exception)
            {
                return new List<ApprovalRequestResponseDto>();
            }
        }

        /// <summary>
        /// Get pending approvals for a specific user
        /// </summary>
        public async Task<IEnumerable<ApprovalRequestResponseDto>> GetPendingApprovalsForUser(
            [Service] IApprovalService approvalService,
            string userEmail)
        {
            try
            {
                return await approvalService.GetPendingApprovalsForUserAsync(userEmail);
            }
            catch (Exception)
            {
                return new List<ApprovalRequestResponseDto>();
            }
        }

        /// <summary>
        /// Get all requests created by a specific user
        /// </summary>
        public async Task<IEnumerable<ApprovalRequestResponseDto>> GetMyRequests(
            [Service] IApprovalService approvalService,
            string userId)
        {
            try
            {
                return await approvalService.GetMyRequestsAsync(userId);
            }
            catch (Exception)
            {
                return new List<ApprovalRequestResponseDto>();
            }
        }
    }
} 