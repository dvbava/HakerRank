using HotChocolate;
using HotChocolate.Types;
using Provenance.Services.Data.ApprovalManager.Models.DTOs;
using Provenance.Services.Data.ApprovalManager.Services;
using Provenance.Services.Data.ApprovalManager.GraphQL.Types;
using System.Text.Json;

namespace Provenance.Services.Data.ApprovalManager.GraphQL.Mutations
{
    [ExtendObjectType("Mutation")]
    public class ApprovalMutations
    {
        /// <summary>
        /// Create a new approval request
        /// </summary>
        public async Task<ApprovalRequestResponseDto?> CreateApprovalRequest(
            [Service] IApprovalService approvalService,
            CreateApprovalRequestInput input)
        {
            try
            {
                var request = new CreateApprovalRequestDto
                {
                    RequestType = input.RequestType,
                    Title = input.Title,
                    Description = input.Description,
                    RequesterId = input.RequesterId,
                    RequesterName = input.RequesterName,
                    RequesterEmail = input.RequesterEmail,
                    OriginatingSystem = input.OriginatingSystem,
                    Priority = input.Priority,
                    FromDate = input.FromDate,
                    ToDate = input.ToDate,
                    Metadata = ParseMetadata(input.Metadata),
                    Approvers = input.Approvers.Select(a => new ApproverDto { ApproverEmail = a.ApproverEmail }).ToList()
                };

                return await approvalService.CreateApprovalRequestAsync(request);
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Update an approval request
        /// </summary>
        public async Task<ApprovalRequestResponseDto?> UpdateApprovalRequest(
            [Service] IApprovalService approvalService,
            Guid primaryGuid,
            UpdateApprovalRequestInput input)
        {
            try
            {
                var request = new UpdateApprovalRequestDto
                {
                    Title = input.Title,
                    Description = input.Description,
                    Priority = input.Priority,
                    FromDate = input.FromDate,
                    ToDate = input.ToDate,
                    Metadata = input.Metadata != null ? ParseMetadata(input.Metadata) : null,
                    Approvers = input.Approvers?.Select(a => new ApproverDto { ApproverEmail = a.ApproverEmail }).ToList()
                };

                return await approvalService.UpdateApprovalRequestAsync(primaryGuid, request);
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Delete an approval request
        /// </summary>
        public async Task<bool> DeleteApprovalRequest(
            [Service] IApprovalService approvalService,
            Guid primaryGuid)
        {
            try
            {
                return await approvalService.DeleteApprovalRequestAsync(primaryGuid);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Approve a request
        /// </summary>
        public async Task<ApprovalRequestResponseDto?> ApproveRequest(
            [Service] IApprovalService approvalService,
            Guid primaryGuid,
            ApproveRequestInput input)
        {
            try
            {
                return await approvalService.ApproveRequestAsync(primaryGuid, input.ApproverEmail, input.Comments);
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Reject a request
        /// </summary>
        public async Task<ApprovalRequestResponseDto?> RejectRequest(
            [Service] IApprovalService approvalService,
            Guid primaryGuid,
            RejectRequestInput input)
        {
            try
            {
                return await approvalService.RejectRequestAsync(primaryGuid, input.RejectorEmail, input.RejectionReason, input.Comments);
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Add a comment to a request
        /// </summary>
        public async Task<ApprovalRequestResponseDto?> CommentOnRequest(
            [Service] IApprovalService approvalService,
            Guid primaryGuid,
            CommentRequestInput input)
        {
            try
            {
                return await approvalService.CommentOnRequestAsync(primaryGuid, input.CommenterId, input.Comments);
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Cancel a request
        /// </summary>
        public async Task<ApprovalRequestResponseDto?> CancelRequest(
            [Service] IApprovalService approvalService,
            Guid primaryGuid,
            CancelRequestInput input)
        {
            try
            {
                return await approvalService.CancelRequestAsync(primaryGuid, input.CancellerId, input.Reason);
            }
            catch (KeyNotFoundException)
            {
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static Dictionary<string, object> ParseMetadata(string metadata)
        {
            try
            {
                return JsonSerializer.Deserialize<Dictionary<string, object>>(metadata) ?? new Dictionary<string, object>();
            }
            catch
            {
                return new Dictionary<string, object>();
            }
        }
    }
} 