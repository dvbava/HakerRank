# GraphQL API Documentation

This document describes the GraphQL endpoints available for the Approval API, which provide the same functionality as the REST API endpoints.

## Endpoints

- **GraphQL Endpoint**: `/graphql`
- **GraphQL Playground**: `/graphql` (when accessed via browser)

## Queries

### Get Approval Request by ID

```graphql
query GetApprovalRequest($id: ID!) {
  approvalRequest(primaryGuid: $id) {
    primaryGuid
    title
    description
    status
    requesterId
    requesterName
    createdAt
    approvers {
      approverEmail
      status
      actionedAt
      comments
    }
  }
}
```

### Get All Approval Requests (with filtering)

```graphql
query GetApprovalRequests($requestType: String, $status: ApprovalStatus, $requesterId: String) {
  approvalRequests(requestType: $requestType, status: $status, requesterId: $requesterId) {
    primaryGuid
    title
    description
    status
    requesterId
    requesterName
    createdAt
    priority
  }
}
```

### Get Pending Approvals for User

```graphql
query GetPendingApprovals($userEmail: String!) {
  pendingApprovalsForUser(userEmail: $userEmail) {
    primaryGuid
    title
    description
    requesterId
    requesterName
    createdAt
    priority
  }
}
```

### Get My Requests

```graphql
query GetMyRequests($userId: String!) {
  myRequests(userId: $userId) {
    primaryGuid
    title
    description
    status
    createdAt
    priority
  }
}
```

## Mutations

### Create Approval Request

```graphql
mutation CreateApprovalRequest($input: CreateApprovalRequestInput!) {
  createApprovalRequest(input: $input) {
    primaryGuid
    title
    description
    status
    requesterId
    requesterName
    createdAt
  }
}
```

Variables:
```json
{
  "input": {
    "requestType": "Vacation",
    "title": "Vacation Request",
    "description": "Annual leave request for 2 weeks",
    "requesterId": "user123",
    "requesterName": "John Doe",
    "requesterEmail": "john.doe@company.com",
    "priority": 2,
    "approvers": [
      {
        "approverEmail": "manager@company.com"
      }
    ]
  }
}
```

### Update Approval Request

```graphql
mutation UpdateApprovalRequest($id: ID!, $input: UpdateApprovalRequestInput!) {
  updateApprovalRequest(primaryGuid: $id, input: $input) {
    primaryGuid
    title
    description
    status
    updatedAt
  }
}
```

### Delete Approval Request

```graphql
mutation DeleteApprovalRequest($id: ID!) {
  deleteApprovalRequest(primaryGuid: $id)
}
```

### Approve Request

```graphql
mutation ApproveRequest($id: ID!, $input: ApproveRequestInput!) {
  approveRequest(primaryGuid: $id, input: $input) {
    primaryGuid
    status
    approvedBy
    approvedAt
    comments
  }
}
```

Variables:
```json
{
  "input": {
    "approverEmail": "manager@company.com",
    "comments": "Approved - enjoy your vacation!"
  }
}
```

### Reject Request

```graphql
mutation RejectRequest($id: ID!, $input: RejectRequestInput!) {
  rejectRequest(primaryGuid: $id, input: $input) {
    primaryGuid
    status
    rejectedBy
    rejectedAt
    rejectionReason
    comments
  }
}
```

Variables:
```json
{
  "input": {
    "rejectorEmail": "manager@company.com",
    "rejectionReason": "Insufficient notice period",
    "comments": "Please submit at least 2 weeks in advance"
  }
}
```

### Comment on Request

```graphql
mutation CommentOnRequest($id: ID!, $input: CommentRequestInput!) {
  commentOnRequest(primaryGuid: $id, input: $input) {
    primaryGuid
    comments
  }
}
```

Variables:
```json
{
  "input": {
    "commenterId": "user123",
    "comments": "Additional context for this request"
  }
}
```

### Cancel Request

```graphql
mutation CancelRequest($id: ID!, $input: CancelRequestInput!) {
  cancelRequest(primaryGuid: $id, input: $input) {
    primaryGuid
    status
  }
}
```

Variables:
```json
{
  "input": {
    "cancellerId": "user123",
    "reason": "No longer needed"
  }
}
```

## Data Types

### ApprovalRequest
- `primaryGuid`: Unique identifier
- `title`: Request title
- `description`: Request description
- `status`: Current status (PENDING, APPROVED, REJECTED, CANCELLED)
- `requesterId`: ID of the person who created the request
- `requesterName`: Name of the requester
- `requesterEmail`: Email of the requester
- `createdAt`: When the request was created
- `priority`: Priority level (1-4)
- `approvers`: List of approvers and their status
- `channels`: List of approval channels

### ApprovalStatus Enum
- `PENDING`: Request is waiting for approval
- `APPROVED`: Request has been approved
- `REJECTED`: Request has been rejected
- `CANCELLED`: Request has been cancelled

## Error Handling

GraphQL returns `null` for the requested field when an error occurs, rather than throwing exceptions. This allows for partial results and graceful error handling.

## Usage Examples

### Using with curl

```bash
# Get all pending requests
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"query":"query { approvalRequests(status: PENDING) { primaryGuid title status } }"}' \
  http://localhost:5000/graphql
```

### Using with JavaScript/TypeScript

```javascript
const response = await fetch('/graphql', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    query: `
      query GetApprovalRequest($id: ID!) {
        approvalRequest(primaryGuid: $id) {
          primaryGuid
          title
          status
        }
      }
    `,
    variables: {
      id: '123e4567-e89b-12d3-a456-426614174000'
    }
  })
});

const data = await response.json();
```

## Comparison with REST API

| REST Endpoint | GraphQL Query/Mutation | Description |
|---------------|------------------------|-------------|
| `GET /api/approval/requests/{id}` | `approvalRequest(id)` | Get specific request |
| `GET /api/approval/requests` | `approvalRequests` | Get all requests with filtering |
| `POST /api/approval/requests` | `createApprovalRequest` | Create new request |
| `PUT /api/approval/requests/{id}` | `updateApprovalRequest` | Update request |
| `DELETE /api/approval/requests/{id}` | `deleteApprovalRequest` | Delete request |
| `POST /api/approval/requests/{id}/approve` | `approveRequest` | Approve request |
| `POST /api/approval/requests/{id}/reject` | `rejectRequest` | Reject request |
| `POST /api/approval/requests/{id}/comment` | `commentOnRequest` | Add comment |
| `POST /api/approval/requests/{id}/cancel` | `cancelRequest` | Cancel request |
| `GET /api/approval/users/{email}/pending-approvals` | `pendingApprovalsForUser` | Get pending approvals |
| `GET /api/approval/users/{id}/my-requests` | `myRequests` | Get user's requests | 