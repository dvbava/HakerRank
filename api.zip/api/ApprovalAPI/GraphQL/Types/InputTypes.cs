using HotChocolate;
using HotChocolate.Types;
using Provenance.Services.Data.ApprovalManager.Models.DTOs;

namespace Provenance.Services.Data.ApprovalManager.GraphQL.Types
{
    public class CreateApprovalRequestInput
    {
        public string RequestType { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string RequesterId { get; set; } = string.Empty;
        public string RequesterName { get; set; } = string.Empty;
        public string RequesterEmail { get; set; } = string.Empty;
        public string OriginatingSystem { get; set; } = string.Empty;
        public int Priority { get; set; } = 1;
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Metadata { get; set; } = "{}";
        public List<ApproverInput> Approvers { get; set; } = new();
    }

    public class ApproverInput
    {
        public string ApproverEmail { get; set; } = string.Empty;
    }

    public class UpdateApprovalRequestInput
    {
        public string? Title { get; set; }
        public string? Description { get; set; }
        public int? Priority { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string? Metadata { get; set; }
        public List<ApproverInput>? Approvers { get; set; }
    }

    public class ApproveRequestInput
    {
        public string ApproverEmail { get; set; } = string.Empty;
        public string? Comments { get; set; }
    }

    public class RejectRequestInput
    {
        public string RejectorEmail { get; set; } = string.Empty;
        public string RejectionReason { get; set; } = string.Empty;
        public string? Comments { get; set; }
    }

    public class CommentRequestInput
    {
        public string CommenterId { get; set; } = string.Empty;
        public string Comments { get; set; } = string.Empty;
    }

    public class CancelRequestInput
    {
        public string CancellerId { get; set; } = string.Empty;
        public string? Reason { get; set; }
    }

    // GraphQL Type Definitions
    public class CreateApprovalRequestInputType : InputObjectType<CreateApprovalRequestInput>
    {
        protected override void Configure(IInputObjectTypeDescriptor<CreateApprovalRequestInput> descriptor)
        {
            descriptor.Name("CreateApprovalRequestInput");
            descriptor.Field(x => x.RequestType).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Title).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Description).Type<StringType>();
            descriptor.Field(x => x.RequesterId).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.RequesterName).Type<StringType>();
            descriptor.Field(x => x.RequesterEmail).Type<StringType>();
            descriptor.Field(x => x.OriginatingSystem).Type<StringType>();
            descriptor.Field(x => x.Priority).Type<IntType>();
            descriptor.Field(x => x.FromDate).Type<DateTimeType>();
            descriptor.Field(x => x.ToDate).Type<DateTimeType>();
            descriptor.Field(x => x.Metadata).Type<StringType>();
            descriptor.Field(x => x.Approvers).Type<ListType<ApproverInputType>>();
        }
    }

    public class ApproverInputType : InputObjectType<ApproverInput>
    {
        protected override void Configure(IInputObjectTypeDescriptor<ApproverInput> descriptor)
        {
            descriptor.Name("ApproverInput");
            descriptor.Field(x => x.ApproverEmail).Type<NonNullType<StringType>>();
        }
    }

    public class UpdateApprovalRequestInputType : InputObjectType<UpdateApprovalRequestInput>
    {
        protected override void Configure(IInputObjectTypeDescriptor<UpdateApprovalRequestInput> descriptor)
        {
            descriptor.Name("UpdateApprovalRequestInput");
            descriptor.Field(x => x.Title).Type<StringType>();
            descriptor.Field(x => x.Description).Type<StringType>();
            descriptor.Field(x => x.Priority).Type<IntType>();
            descriptor.Field(x => x.FromDate).Type<DateTimeType>();
            descriptor.Field(x => x.ToDate).Type<DateTimeType>();
            descriptor.Field(x => x.Metadata).Type<StringType>();
            descriptor.Field(x => x.Approvers).Type<ListType<ApproverInputType>>();
        }
    }

    public class ApproveRequestInputType : InputObjectType<ApproveRequestInput>
    {
        protected override void Configure(IInputObjectTypeDescriptor<ApproveRequestInput> descriptor)
        {
            descriptor.Name("ApproveRequestInput");
            descriptor.Field(x => x.ApproverEmail).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Comments).Type<StringType>();
        }
    }

    public class RejectRequestInputType : InputObjectType<RejectRequestInput>
    {
        protected override void Configure(IInputObjectTypeDescriptor<RejectRequestInput> descriptor)
        {
            descriptor.Name("RejectRequestInput");
            descriptor.Field(x => x.RejectorEmail).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.RejectionReason).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Comments).Type<StringType>();
        }
    }

    public class CommentRequestInputType : InputObjectType<CommentRequestInput>
    {
        protected override void Configure(IInputObjectTypeDescriptor<CommentRequestInput> descriptor)
        {
            descriptor.Name("CommentRequestInput");
            descriptor.Field(x => x.CommenterId).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Comments).Type<NonNullType<StringType>>();
        }
    }

    public class CancelRequestInputType : InputObjectType<CancelRequestInput>
    {
        protected override void Configure(IInputObjectTypeDescriptor<CancelRequestInput> descriptor)
        {
            descriptor.Name("CancelRequestInput");
            descriptor.Field(x => x.CancellerId).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Reason).Type<StringType>();
        }
    }
} 