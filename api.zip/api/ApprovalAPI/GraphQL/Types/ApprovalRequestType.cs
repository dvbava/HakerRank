using HotChocolate;
using HotChocolate.Types;
using Provenance.Services.Data.ApprovalManager.Models;
using Provenance.Services.Data.ApprovalManager.Models.DTOs;

namespace Provenance.Services.Data.ApprovalManager.GraphQL.Types
{
    public class ApprovalRequestType : ObjectType<ApprovalRequestResponseDto>
    {
        protected override void Configure(IObjectTypeDescriptor<ApprovalRequestResponseDto> descriptor)
        {
            descriptor.Name("ApprovalRequest");
            descriptor.Description("An approval request");

            descriptor.Field(x => x.PrimaryGuid).Type<NonNullType<UuidType>>();
            descriptor.Field(x => x.InternalGuid).Type<NonNullType<UuidType>>();
            descriptor.Field(x => x.RequestType).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Title).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Description).Type<StringType>();
            descriptor.Field(x => x.RequesterId).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.RequesterName).Type<StringType>();
            descriptor.Field(x => x.RequesterEmail).Type<StringType>();
            descriptor.Field(x => x.OriginatingSystem).Type<StringType>();
            descriptor.Field(x => x.CreatedAt).Type<NonNullType<DateTimeType>>();
            descriptor.Field(x => x.UpdatedAt).Type<DateTimeType>();
            descriptor.Field(x => x.Version).Type<NonNullType<IntType>>();
            descriptor.Field(x => x.Status).Type<NonNullType<EnumType<ApprovalStatus>>>();
            descriptor.Field(x => x.CompletedAt).Type<DateTimeType>();
            descriptor.Field(x => x.Comments).Type<StringType>();
            descriptor.Field(x => x.RejectionReason).Type<StringType>();
            descriptor.Field(x => x.ApprovedBy).Type<StringType>();
            descriptor.Field(x => x.RejectedBy).Type<StringType>();
            descriptor.Field(x => x.ApprovedAt).Type<DateTimeType>();
            descriptor.Field(x => x.RejectedAt).Type<DateTimeType>();
            descriptor.Field(x => x.Metadata).Type<StringType>();
            descriptor.Field(x => x.Priority).Type<NonNullType<IntType>>();
            descriptor.Field(x => x.FromDate).Type<DateTimeType>();
            descriptor.Field(x => x.ToDate).Type<DateTimeType>();
            descriptor.Field(x => x.Approvers).Type<ListType<ApproverStatusType>>();
            descriptor.Field(x => x.Channels).Type<ListType<ChannelStatusType>>();
        }
    }

    public class ApproverStatusType : ObjectType<ApproverStatusDto>
    {
        protected override void Configure(IObjectTypeDescriptor<ApproverStatusDto> descriptor)
        {
            descriptor.Name("ApproverStatus");
            descriptor.Description("Status of an approver for an approval request");

            descriptor.Field(x => x.ApproverEmail).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Status).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.ActionedAt).Type<DateTimeType>();
            descriptor.Field(x => x.Comments).Type<StringType>();
        }
    }

    public class ChannelStatusType : ObjectType<ChannelStatusDto>
    {
        protected override void Configure(IObjectTypeDescriptor<ChannelStatusDto> descriptor)
        {
            descriptor.Name("ChannelStatus");
            descriptor.Description("Status of a channel for an approval request");

            descriptor.Field(x => x.ChannelType).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.Status).Type<NonNullType<StringType>>();
            descriptor.Field(x => x.ActivatedAt).Type<DateTimeType>();
            descriptor.Field(x => x.CompletedAt).Type<DateTimeType>();
            descriptor.Field(x => x.ChannelSpecificData).Type<StringType>();
        }
    }
} 