using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Provenance.Services.Data.ApprovalManager.Models
{
    public class ApprovalRequest
    {
        [Key]
        public Guid PrimaryGuid { get; set; } = Guid.NewGuid();
        public Guid InternalGuid { get; set; } = Guid.NewGuid();
        
        [Required]
        [MaxLength(100)]
        public string RequestType { get; set; } = string.Empty;
        
        [Required]
        [MaxLength(200)]
        public string Title { get; set; } = string.Empty;
        
        [MaxLength(1000)]
        public string Description { get; set; } = string.Empty;
        
        [Required]
        [MaxLength(100)]
        public string RequesterId { get; set; } = string.Empty;
        
        [MaxLength(200)]
        public string RequesterName { get; set; } = string.Empty;
        
        [MaxLength(200)]
        public string RequesterEmail { get; set; } = string.Empty;
        
        [MaxLength(100)]
        public string OriginatingSystem { get; set; } = string.Empty;
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        public DateTime? UpdatedAt { get; set; }
        
        public int Version { get; set; } = 1;
        
        public ApprovalStatus Status { get; set; } = ApprovalStatus.Pending;
        
        public virtual ICollection<ApprovalRequestApprover> Approvers { get; set; } = new List<ApprovalRequestApprover>();
        
        public virtual ICollection<ApprovalChannel> Channels { get; set; } = new List<ApprovalChannel>();
        
        public DateTime? CompletedAt { get; set; }
        
        [MaxLength(1000)]
        public string? Comments { get; set; }
        
        [MaxLength(500)]
        public string? RejectionReason { get; set; }
        
        [MaxLength(100)]
        public string? ApprovedBy { get; set; }
        
        [MaxLength(100)]
        public string? RejectedBy { get; set; }
        
        public DateTime? ApprovedAt { get; set; }
        
        public DateTime? RejectedAt { get; set; }
        
        // Generic properties to store approval-specific data
        [Column(TypeName = "nvarchar(max)")]
        public string Metadata { get; set; } = "{}";
        
        public int Priority { get; set; } = 1; // 1=Low, 2=Medium, 3=High, 4=Critical
        
        public DateTime? FromDate { get; set; }
        
        public DateTime? ToDate { get; set; }
        
        // Remove any reference to ApprovalAction
    }

    public enum ApprovalStatus
    {
        Pending,
        Approved,
        Rejected,
        Cancelled
    }
} 