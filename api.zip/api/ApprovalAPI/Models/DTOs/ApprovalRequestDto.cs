using System.ComponentModel.DataAnnotations;
using System.Text.Json;

namespace Provenance.Services.Data.ApprovalManager.Models.DTOs
{
    public class CreateApprovalRequestDto
    {
        [Required]
        public string RequestType { get; set; } = string.Empty;
        
        [Required]
        public string Title { get; set; } = string.Empty;
        
        public string Description { get; set; } = string.Empty;
        
        [Required]
        public string RequesterId { get; set; } = string.Empty;
        
        public string RequesterName { get; set; } = string.Empty;
        
        public string RequesterEmail { get; set; } = string.Empty;
        
        public string OriginatingSystem { get; set; } = string.Empty;
        
        public int Priority { get; set; } = 1;
        
        public DateTime? FromDate { get; set; }
        
        public DateTime? ToDate { get; set; }
        
        public Dictionary<string, object> Metadata { get; set; } = new();

        public List<ApproverDto> Approvers { get; set; } = new();
    }

    public class ChannelDto
    {
        public string ChannelType { get; set; } = string.Empty;
        public Dictionary<string, object>? ChannelSpecificData { get; set; }
    }

    public class ApproverDto
    {
        public string ApproverEmail { get; set; } = string.Empty;
    }

    public class UpdateApprovalRequestDto
    {
        public string? Title { get; set; }
        
        public string? Description { get; set; }
        
        public int? Priority { get; set; }
        
        public DateTime? FromDate { get; set; }
        
        public DateTime? ToDate { get; set; }
        
        public Dictionary<string, object>? Metadata { get; set; }

        public List<ApproverDto>? Approvers { get; set; }
    }

    public class ApprovalRequestResponseDto
    {
        public Guid PrimaryGuid { get; set; }
        public Guid InternalGuid { get; set; }
        
        public string RequestType { get; set; } = string.Empty;
        
        public string Title { get; set; } = string.Empty;
        
        public string Description { get; set; } = string.Empty;
        
        public string RequesterId { get; set; } = string.Empty;
        
        public string RequesterName { get; set; } = string.Empty;
        
        public string RequesterEmail { get; set; } = string.Empty;
        
        public string OriginatingSystem { get; set; } = string.Empty;
        
        public DateTime CreatedAt { get; set; }
        
        public DateTime? UpdatedAt { get; set; }
        
        public int Version { get; set; }
        
        public ApprovalStatus Status { get; set; }
        
        public DateTime? CompletedAt { get; set; }
        
        public string? Comments { get; set; }
        
        public string? RejectionReason { get; set; }
        
        public string? ApprovedBy { get; set; }
        
        public string? RejectedBy { get; set; }
        
        public DateTime? ApprovedAt { get; set; }
        
        public DateTime? RejectedAt { get; set; }
        
        public Dictionary<string, object> Metadata { get; set; } = new();
        
        public int Priority { get; set; }
        
        public DateTime? FromDate { get; set; }
        
        public DateTime? ToDate { get; set; }
        public List<ApproverStatusDto> Approvers { get; set; } = new();
        public List<ChannelStatusDto> Channels { get; set; } = new();
    }

    public class ChannelStatusDto
    {
        public string ChannelType { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public DateTime? ActivatedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        public Dictionary<string, object>? ChannelSpecificData { get; set; }
    }

    public class ApproverStatusDto
    {
        public string ApproverEmail { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public DateTime? ActionedAt { get; set; }
        public string? Comments { get; set; }
    }
} 