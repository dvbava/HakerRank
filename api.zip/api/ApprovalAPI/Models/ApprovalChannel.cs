using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Provenance.Services.Data.ApprovalManager.Models
{
    public class ApprovalChannel
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        public Guid ApprovalRequestPrimaryGuid { get; set; }

        [ForeignKey("ApprovalRequestPrimaryGuid")]
        public virtual ApprovalRequest ApprovalRequest { get; set; } = null!;

        [Required]
        [MaxLength(50)]
        public string ChannelType { get; set; } = string.Empty; // Manual, Web, Chat, Email, etc.

        [Required]
        public ChannelStatus Status { get; set; } = ChannelStatus.Available;

        public DateTime? ActivatedAt { get; set; }

        public DateTime? CompletedAt { get; set; }

        [MaxLength(500)]
        public string? ChannelSpecificData { get; set; } // JSON data for channel-specific information

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedAt { get; set; }
    }

    public enum ChannelStatus
    {
        Available,      // Channel is available for approval
        Active,         // Channel is currently being used for approval
        Completed,      // Approval completed through this channel
        Disabled        // Channel is disabled/not available
    }
} 