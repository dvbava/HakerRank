using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Provenance.Services.Data.ApprovalManager.Models
{
    public class ApprovalRequestApprover
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        public Guid ApprovalRequestPrimaryGuid { get; set; }

        [ForeignKey("ApprovalRequestPrimaryGuid")]
        public virtual ApprovalRequest ApprovalRequest { get; set; } = null!;

        [Required]
        [MaxLength(200)]
        public string ApproverEmail { get; set; } = string.Empty;

        [Required]
        public ApproverStatus Status { get; set; } = ApproverStatus.Pending;

        public DateTime? ActionedAt { get; set; }

        public string? Comments { get; set; }
    }

    public enum ApproverStatus
    {
        Pending,
        Approved,
        Rejected
    }
}