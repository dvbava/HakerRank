using System.ComponentModel.DataAnnotations;

namespace Provenance.Services.Data.ApprovalManager.Models
{
    public class SystemConfiguration
    {
        [Key]
        public string ConfigurationKey { get; set; } = string.Empty;
        
        [Required]
        public string ConfigurationValue { get; set; } = string.Empty;
        
        public string? Description { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        public DateTime? UpdatedAt { get; set; }
    }
} 