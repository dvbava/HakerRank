using Provenance.Services.Data.ApprovalManager.Models;
using Provenance.Services.Data.ApprovalManager.Models.DTOs;

namespace Provenance.Services.Data.ApprovalManager.Services
{
    public interface IApprovalService
    {
        Task<ApprovalRequestResponseDto> CreateApprovalRequestAsync(CreateApprovalRequestDto request);
        Task<ApprovalRequestResponseDto> GetApprovalRequestAsync(Guid primaryGuid);
        Task<IEnumerable<ApprovalRequestResponseDto>> GetApprovalRequestsAsync(string? requestType = null, ApprovalStatus? status = null, string? requesterId = null);
        Task<ApprovalRequestResponseDto> UpdateApprovalRequestAsync(Guid primaryGuid, UpdateApprovalRequestDto request);
        Task<bool> DeleteApprovalRequestAsync(Guid primaryGuid);
        
        Task<ApprovalRequestResponseDto> ApproveRequestAsync(Guid primaryGuid, string approverEmail, string? comments = null);
        Task<ApprovalRequestResponseDto> RejectRequestAsync(Guid primaryGuid, string rejectorEmail, string rejectionReason, string? comments = null);
        Task<ApprovalRequestResponseDto> CommentOnRequestAsync(Guid primaryGuid, string commenterId, string comments);
        Task<ApprovalRequestResponseDto> CancelRequestAsync(Guid primaryGuid, string cancellerId, string? reason = null);
        
        Task<IEnumerable<ApprovalRequestResponseDto>> GetPendingApprovalsForUserAsync(string userEmail);
        Task<IEnumerable<ApprovalRequestResponseDto>> GetMyRequestsAsync(string userId);
        
        // Removed ApprovalAction-related methods
    }
} 