namespace Provenance.Services.Data.ApprovalManager.Services.Email
{
    public interface IEmailService
    {
        Task SendEmailAsync(string to, string subject, string body);
    }
}