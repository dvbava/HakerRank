using System.Net.Mail;
using System.Net;
using Microsoft.Extensions.Options;
using Provenance.Services.Data.ApprovalManager.Models;

namespace Provenance.Services.Data.ApprovalManager.Services.Email
{
    public class EmailService : IEmailService
    {
        private readonly SmtpSettings _smtpSettings;

        public EmailService(IOptions<SmtpSettings> smtpSettings)
        {
            _smtpSettings = smtpSettings.Value;
        }

        public async Task SendEmailAsync(string to, string subject, string body)
        {
            try
            {
                using var client = new SmtpClient(_smtpSettings.Host, _smtpSettings.Port)
                {
                    EnableSsl = _smtpSettings.EnableSsl,
                    Credentials = new NetworkCredential(_smtpSettings.User, _smtpSettings.Password)
                };

                var message = new MailMessage
                {
                    From = new MailAddress(_smtpSettings.From, _smtpSettings.FromName),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = false
                };
                message.To.Add(to);

                await client.SendMailAsync(message);
                
                Console.WriteLine($"[EMAIL SENT] To: {to}, Subject: {subject}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[EMAIL ERROR] Failed to send email to {to}: {ex.Message}");
                // In production, you might want to log this properly or handle it differently
            }
        }
    }
}