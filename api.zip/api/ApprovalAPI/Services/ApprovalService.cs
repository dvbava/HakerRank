using Provenance.Services.Data.ApprovalManager.Models;
using Provenance.Services.Data.ApprovalManager.Models.DTOs;
using Provenance.Services.Data.ApprovalManager.Data;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using Provenance.Services.Data.ApprovalManager.Services.Email;

namespace Provenance.Services.Data.ApprovalManager.Services
{
    public class ApprovalService : IApprovalService
    {
        private readonly ApprovalDbContext _context;
        private readonly IEmailService _emailService;
        private readonly IConfigurationService _configurationService;

        public ApprovalService(ApprovalDbContext context, IEmailService emailService, IConfigurationService configurationService)
        {
            _context = context;
            _emailService = emailService;
            _configurationService = configurationService;
        }

        public async Task<ApprovalRequestResponseDto> CreateApprovalRequestAsync(CreateApprovalRequestDto request)
        {
            var approvalRequest = new ApprovalRequest
            {
                RequestType = request.RequestType,
                Title = request.Title,
                Description = request.Description,
                RequesterId = request.RequesterId,
                RequesterName = request.RequesterName,
                RequesterEmail = request.RequesterEmail,
                OriginatingSystem = request.OriginatingSystem,
                Priority = request.Priority,
                FromDate = request.FromDate,
                ToDate = request.ToDate,
                Metadata = JsonSerializer.Serialize(request.Metadata),
                Version = 1
            };

            _context.ApprovalRequests.Add(approvalRequest);
            await _context.SaveChangesAsync();

            // Create channels from system configuration
            var activeChannels = await _configurationService.GetActiveChannelsAsync();
            if (activeChannels.Any())
            {
                foreach (var activeChannel in activeChannels)
                {
                    var channel = new ApprovalChannel
                    {
                        ApprovalRequestPrimaryGuid = approvalRequest.PrimaryGuid,
                        ChannelType = activeChannel.ChannelType,
                        Status = ChannelStatus.Available,
                        ChannelSpecificData = activeChannel.ChannelSpecificData
                    };
                    _context.ApprovalChannels.Add(channel);
                }
                await _context.SaveChangesAsync();
            }

            // Create approvers and send email notifications
            if (request.Approvers != null && request.Approvers.Any())
            {
                foreach (var approverDto in request.Approvers)
                {
                    var approver = new ApprovalRequestApprover
                    {
                        ApprovalRequestPrimaryGuid = approvalRequest.PrimaryGuid,
                        ApproverEmail = approverDto.ApproverEmail,
                        Status = ApproverStatus.Pending
                    };
                    _context.ApprovalRequestApprovers.Add(approver);

                    // Send email notification to approver
                    if (!string.IsNullOrEmpty(approver.ApproverEmail))
                    {
                        await _emailService.SendEmailAsync(
                            approver.ApproverEmail,
                            $"Approval Request Assigned: {approvalRequest.Title}",
                            $"You have been assigned a new approval request (ID: {approvalRequest.PrimaryGuid})."
                        );
                    }
                }
                await _context.SaveChangesAsync();
            }

            return MapToResponseDto(approvalRequest);
        }

        public async Task<ApprovalRequestResponseDto> GetApprovalRequestAsync(Guid id)
        {
            var request = await _context.ApprovalRequests
                .Include(r => r.Approvers)
                .Include(r => r.Channels)
                .FirstOrDefaultAsync(r => r.PrimaryGuid == id);

            if (request == null)
                throw new KeyNotFoundException($"Approval request with ID {id} not found.");

            return MapToResponseDto(request);
        }

        public async Task<IEnumerable<ApprovalRequestResponseDto>> GetApprovalRequestsAsync(string? requestType = null, ApprovalStatus? status = null, string? requesterId = null)
        {
            var query = _context.ApprovalRequests
                .Include(r => r.Approvers)
                .Include(r => r.Channels)
                .AsQueryable();

            if (!string.IsNullOrEmpty(requestType))
                query = query.Where(r => r.RequestType == requestType);

            if (status.HasValue)
                query = query.Where(r => r.Status == status.Value);

            if (!string.IsNullOrEmpty(requesterId))
                query = query.Where(r => r.RequesterId == requesterId);

            var requests = await query.ToListAsync();
            return requests.Select(r => MapToResponseDto(r));
        }

        public async Task<ApprovalRequestResponseDto> UpdateApprovalRequestAsync(Guid id, UpdateApprovalRequestDto request)
        {
            var existingRequest = await _context.ApprovalRequests
                .Include(r => r.Approvers)
                .Include(r => r.Channels)
                .FirstOrDefaultAsync(r => r.PrimaryGuid == id);
            if (existingRequest == null)
                throw new KeyNotFoundException($"Approval request with ID {id} not found.");

            // Only allow updates if request is still pending
            if (existingRequest.Status != ApprovalStatus.Pending)
                throw new InvalidOperationException("Cannot update a request that is not in pending status.");

            if (!string.IsNullOrEmpty(request.Title))
                existingRequest.Title = request.Title;

            if (!string.IsNullOrEmpty(request.Description))
                existingRequest.Description = request.Description;

            if (request.Priority.HasValue)
                existingRequest.Priority = request.Priority.Value;

            if (request.FromDate.HasValue)
                existingRequest.FromDate = request.FromDate;

            if (request.ToDate.HasValue)
                existingRequest.ToDate = request.ToDate;

            if (request.Metadata != null)
                existingRequest.Metadata = JsonSerializer.Serialize(request.Metadata);

            // Handle approvers update
            if (request.Approvers != null)
            {
                // Remove existing approvers
                var existingApprovers = existingRequest.Approvers.ToList();
                foreach (var approver in existingApprovers)
                {
                    _context.ApprovalRequestApprovers.Remove(approver);
                }

                // Add new approvers
                foreach (var approverDto in request.Approvers)
                {
                    var approver = new ApprovalRequestApprover
                    {
                        ApprovalRequestPrimaryGuid = existingRequest.PrimaryGuid,
                        ApproverEmail = approverDto.ApproverEmail,
                        Status = ApproverStatus.Pending
                    };
                    _context.ApprovalRequestApprovers.Add(approver);

                    // Send email notification to new approver
                    if (!string.IsNullOrEmpty(approver.ApproverEmail))
                    {
                        await _emailService.SendEmailAsync(
                            approver.ApproverEmail,
                            $"Approval Request Assigned: {existingRequest.Title}",
                            $"You have been assigned a new approval request (ID: {existingRequest.PrimaryGuid})."
                        );
                    }
                }
            }

            // Handle channels update - use system configuration
            var activeChannels = await _configurationService.GetActiveChannelsAsync();
            if (activeChannels.Any())
            {
                // Remove existing channels
                var existingChannels = existingRequest.Channels.ToList();
                foreach (var channel in existingChannels)
                {
                    _context.ApprovalChannels.Remove(channel);
                }

                // Add new channels from system configuration
                foreach (var activeChannel in activeChannels)
                {
                    var channel = new ApprovalChannel
                    {
                        ApprovalRequestPrimaryGuid = existingRequest.PrimaryGuid,
                        ChannelType = activeChannel.ChannelType,
                        Status = ChannelStatus.Available,
                        ChannelSpecificData = activeChannel.ChannelSpecificData
                    };
                    _context.ApprovalChannels.Add(channel);
                }
            }

            existingRequest.UpdatedAt = DateTime.UtcNow;
            existingRequest.Version++;

            await _context.SaveChangesAsync();

            return MapToResponseDto(existingRequest);
        }

        public async Task<bool> DeleteApprovalRequestAsync(Guid id)
        {
            var request = await _context.ApprovalRequests.FindAsync(id);
            if (request == null)
                return false;

            _context.ApprovalRequests.Remove(request);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<ApprovalRequestResponseDto> ApproveRequestAsync(Guid requestId, string approverEmail, string? comments = null)
        {
            var request = await _context.ApprovalRequests
                .Include(r => r.Approvers)
                .FirstOrDefaultAsync(r => r.PrimaryGuid == requestId);
            if (request == null)
                throw new KeyNotFoundException($"Approval request with ID {requestId} not found.");

            if (request.Status == ApprovalStatus.Approved)
                throw new InvalidOperationException("Request is already approved.");
            if (request.Status == ApprovalStatus.Rejected)
                throw new InvalidOperationException("Request is already rejected.");

            var approver = request.Approvers.FirstOrDefault(a => a.ApproverEmail == approverEmail);
            if (approver == null)
                throw new KeyNotFoundException($"Approver {approverEmail} is not assigned to this request.");
            if (approver.Status == ApproverStatus.Approved)
                throw new InvalidOperationException("This approver has already approved the request.");
            if (approver.Status == ApproverStatus.Rejected)
                throw new InvalidOperationException("This approver has already rejected the request.");

            approver.Status = ApproverStatus.Approved;
            approver.Comments = comments;
            approver.ActionedAt = DateTime.UtcNow;

            // As soon as any approver approves, mark the request as approved
            request.Status = ApprovalStatus.Approved;
            request.ApprovedBy = approverEmail;
            request.ApprovedAt = DateTime.UtcNow;
            request.CompletedAt = DateTime.UtcNow;
            request.UpdatedAt = DateTime.UtcNow;
            request.Version++;

            await _context.SaveChangesAsync();

            // Send email notification to requester
            if (!string.IsNullOrEmpty(request.RequesterEmail))
            {
                var emailBody = $"Your approval request '{request.Title}' (ID: {request.PrimaryGuid}) has been approved by {approverEmail}.";
                if (!string.IsNullOrEmpty(comments))
                {
                    emailBody += $"\n\nComments: {comments}";
                }
                await _emailService.SendEmailAsync(
                    request.RequesterEmail,
                    $"Approval Request Approved: {request.Title}",
                    emailBody
                );
            }

            return MapToResponseDto(request);
        }

        public async Task<ApprovalRequestResponseDto> RejectRequestAsync(Guid requestId, string rejectorEmail, string rejectionReason, string? comments = null)
        {
            var request = await _context.ApprovalRequests
                .Include(r => r.Approvers)
                .FirstOrDefaultAsync(r => r.PrimaryGuid == requestId);
            if (request == null)
                throw new KeyNotFoundException($"Approval request with ID {requestId} not found.");

            if (request.Status == ApprovalStatus.Approved)
                throw new InvalidOperationException("Request is already approved.");
            if (request.Status == ApprovalStatus.Rejected)
                throw new InvalidOperationException("Request is already rejected.");

            var approver = request.Approvers.FirstOrDefault(a => a.ApproverEmail == rejectorEmail);
            if (approver == null)
                throw new KeyNotFoundException($"Approver {rejectorEmail} is not assigned to this request.");
            if (approver.Status == ApproverStatus.Approved)
                throw new InvalidOperationException("This approver has already approved the request.");
            if (approver.Status == ApproverStatus.Rejected)
                throw new InvalidOperationException("This approver has already rejected the request.");

            approver.Status = ApproverStatus.Rejected;
            approver.Comments = comments ?? rejectionReason;
            approver.ActionedAt = DateTime.UtcNow;

            // As soon as any approver rejects, mark the request as rejected
            request.Status = ApprovalStatus.Rejected;
            request.RejectedBy = rejectorEmail;
            request.RejectedAt = DateTime.UtcNow;
            request.RejectionReason = rejectionReason;
            request.CompletedAt = DateTime.UtcNow;
            request.UpdatedAt = DateTime.UtcNow;
            request.Version++;

            await _context.SaveChangesAsync();

            // Send email notification to requester
            if (!string.IsNullOrEmpty(request.RequesterEmail))
            {
                var emailBody = $"Your approval request '{request.Title}' (ID: {request.PrimaryGuid}) has been rejected by {rejectorEmail}.";
                emailBody += $"\n\nRejection Reason: {rejectionReason}";
                if (!string.IsNullOrEmpty(comments))
                {
                    emailBody += $"\n\nComments: {comments}";
                }
                await _emailService.SendEmailAsync(
                    request.RequesterEmail,
                    $"Approval Request Rejected: {request.Title}",
                    emailBody
                );
            }

            return MapToResponseDto(request);
        }

        public async Task<ApprovalRequestResponseDto> CommentOnRequestAsync(Guid requestId, string commenterId, string comments)
        {
            var request = await _context.ApprovalRequests.FindAsync(requestId);
            if (request == null)
                throw new KeyNotFoundException($"Approval request with ID {requestId} not found.");

            request.Comments = comments;
            request.UpdatedAt = DateTime.UtcNow;
            request.Version++;

            await _context.SaveChangesAsync();

            return MapToResponseDto(request);
        }

        public async Task<ApprovalRequestResponseDto> CancelRequestAsync(Guid requestId, string cancellerId, string? reason = null)
        {
            var request = await _context.ApprovalRequests.FindAsync(requestId);
            if (request == null)
                throw new KeyNotFoundException($"Approval request with ID {requestId} not found.");

            request.Status = ApprovalStatus.Cancelled;
            request.UpdatedAt = DateTime.UtcNow;
            request.Version++;

            await _context.SaveChangesAsync();

            return MapToResponseDto(request);
        }

        public async Task<IEnumerable<ApprovalRequestResponseDto>> GetPendingApprovalsForUserAsync(string userEmail)
        {
            var requests = await _context.ApprovalRequests
                .Include(r => r.Approvers)
                .Include(r => r.Channels)
                .Where(r => r.Status == ApprovalStatus.Pending && 
                           r.Approvers.Any(a => a.ApproverEmail == userEmail && a.Status == ApproverStatus.Pending))
                .ToListAsync();

            return requests.Select(r => MapToResponseDto(r));
        }

        public async Task<IEnumerable<ApprovalRequestResponseDto>> GetMyRequestsAsync(string userId)
        {
            var requests = await _context.ApprovalRequests
                .Include(r => r.Approvers)
                .Include(r => r.Channels)
                .Where(r => r.RequesterId == userId)
                .ToListAsync();
                
            return requests.Select(r => MapToResponseDto(r));
        }

        private ApprovalRequestResponseDto MapToResponseDto(ApprovalRequest request)
        {
            return new ApprovalRequestResponseDto
            {
                PrimaryGuid = request.PrimaryGuid,
                InternalGuid = request.InternalGuid,
                RequestType = request.RequestType,
                Title = request.Title,
                Description = request.Description,
                RequesterId = request.RequesterId,
                RequesterName = request.RequesterName,
                RequesterEmail = request.RequesterEmail,
                OriginatingSystem = request.OriginatingSystem,
                CreatedAt = request.CreatedAt,
                UpdatedAt = request.UpdatedAt,
                Version = request.Version,
                Status = request.Status,
                CompletedAt = request.CompletedAt,
                Comments = request.Comments,
                RejectionReason = request.RejectionReason,
                ApprovedBy = request.ApprovedBy,
                RejectedBy = request.RejectedBy,
                ApprovedAt = request.ApprovedAt,
                RejectedAt = request.RejectedAt,
                Metadata = ParseMetadata(request.Metadata),
                Priority = request.Priority,
                FromDate = request.FromDate,
                ToDate = request.ToDate,
                Approvers = request.Approvers?.Select(a => new ApproverStatusDto
                {
                    ApproverEmail = a.ApproverEmail,
                    Status = a.Status.ToString(),
                    ActionedAt = a.ActionedAt,
                    Comments = a.Comments
                }).ToList() ?? new List<ApproverStatusDto>(),
                Channels = request.Channels?.Select(c => new ChannelStatusDto
                {
                    ChannelType = c.ChannelType,
                    Status = c.Status.ToString(),
                    ActivatedAt = c.ActivatedAt,
                    CompletedAt = c.CompletedAt,
                    ChannelSpecificData = !string.IsNullOrEmpty(c.ChannelSpecificData) ? 
                        JsonSerializer.Deserialize<Dictionary<string, object>>(c.ChannelSpecificData) : null
                }).ToList() ?? new List<ChannelStatusDto>()
            };
        }

        private Dictionary<string, object> ParseMetadata(string metadata)
        {
            try
            {
                if (string.IsNullOrEmpty(metadata) || metadata == "{}")
                    return new Dictionary<string, object>();

                return JsonSerializer.Deserialize<Dictionary<string, object>>(metadata) ?? new Dictionary<string, object>();
            }
            catch
            {
                return new Dictionary<string, object>();
            }
        }
    }
}