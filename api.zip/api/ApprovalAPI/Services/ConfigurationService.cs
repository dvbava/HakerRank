using Provenance.Services.Data.ApprovalManager.Models;
using Provenance.Services.Data.ApprovalManager.Data;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace Provenance.Services.Data.ApprovalManager.Services
{
    public class ConfigurationService : IConfigurationService
    {
        private readonly ApprovalDbContext _context;

        public ConfigurationService(ApprovalDbContext context)
        {
            _context = context;
        }

        public async Task<List<ApprovalChannel>> GetActiveChannelsAsync()
        {
            var configValue = await GetConfigurationValueAsync("ActiveChannels");
            if (string.IsNullOrEmpty(configValue))
                return new List<ApprovalChannel>();

            try
            {
                var channels = JsonSerializer.Deserialize<List<ApprovalChannel>>(configValue);
                return channels ?? new List<ApprovalChannel>();
            }
            catch
            {
                return new List<ApprovalChannel>();
            }
        }

        public async Task SetActiveChannelsAsync(List<ApprovalChannel> channels)
        {
            var configValue = JsonSerializer.Serialize(channels);
            await SetConfigurationValueAsync("ActiveChannels", configValue, "System-wide active channels for approval requests");
        }

        public async Task<string?> GetConfigurationValueAsync(string key)
        {
            var config = await _context.SystemConfigurations
                .FirstOrDefaultAsync(c => c.ConfigurationKey == key);
            
            return config?.ConfigurationValue;
        }

        public async Task SetConfigurationValueAsync(string key, string value, string? description = null)
        {
            var config = await _context.SystemConfigurations
                .FirstOrDefaultAsync(c => c.ConfigurationKey == key);

            if (config == null)
            {
                config = new SystemConfiguration
                {
                    ConfigurationKey = key,
                    ConfigurationValue = value,
                    Description = description
                };
                _context.SystemConfigurations.Add(config);
            }
            else
            {
                config.ConfigurationValue = value;
                config.Description = description;
                config.UpdatedAt = DateTime.UtcNow;
            }

            await _context.SaveChangesAsync();
        }
    }
} 