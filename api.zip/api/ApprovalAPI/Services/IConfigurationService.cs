using Provenance.Services.Data.ApprovalManager.Models;

namespace Provenance.Services.Data.ApprovalManager.Services
{
    public interface IConfigurationService
    {
        Task<List<ApprovalChannel>> GetActiveChannelsAsync();
        Task SetActiveChannelsAsync(List<ApprovalChannel> channels);
        Task<string?> GetConfigurationValueAsync(string key);
        Task SetConfigurationValueAsync(string key, string value, string? description = null);
    }
} 