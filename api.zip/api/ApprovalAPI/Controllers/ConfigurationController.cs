using Microsoft.AspNetCore.Mvc;
using Provenance.Services.Data.ApprovalManager.Models;
using Provenance.Services.Data.ApprovalManager.Services;

namespace Provenance.Services.Data.ApprovalManager.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ConfigurationController : ControllerBase
    {
        private readonly IConfigurationService _configurationService;

        public ConfigurationController(IConfigurationService configurationService)
        {
            _configurationService = configurationService;
        }

        /// <summary>
        /// Get active channels configuration
        /// </summary>
        [HttpGet("channels/active")]
        public async Task<ActionResult<List<ApprovalChannel>>> GetActiveChannels()
        {
            try
            {
                var channels = await _configurationService.GetActiveChannelsAsync();
                return Ok(channels);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Set active channels configuration
        /// </summary>
        [HttpPost("channels/active")]
        public async Task<ActionResult> SetActiveChannels([FromBody] List<ApprovalChannel> channels)
        {
            try
            {
                await _configurationService.SetActiveChannelsAsync(channels);
                return Ok(new { message = "Active channels updated successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Get configuration value by key
        /// </summary>
        [HttpGet("{key}")]
        public async Task<ActionResult<string>> GetConfigurationValue(string key)
        {
            try
            {
                var value = await _configurationService.GetConfigurationValueAsync(key);
                if (value == null)
                    return NotFound(new { error = $"Configuration key '{key}' not found" });

                return Ok(new { key, value });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Set configuration value by key
        /// </summary>
        [HttpPost("{key}")]
        public async Task<ActionResult> SetConfigurationValue(string key, [FromBody] SetConfigurationRequest request)
        {
            try
            {
                await _configurationService.SetConfigurationValueAsync(key, request.Value, request.Description);
                return Ok(new { message = $"Configuration key '{key}' updated successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
    }

    public class SetConfigurationRequest
    {
        public string Value { get; set; } = string.Empty;
        public string? Description { get; set; }
    }
} 