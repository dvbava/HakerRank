using Microsoft.AspNetCore.Mvc;
using Provenance.Services.Data.ApprovalManager.Models;
using Provenance.Services.Data.ApprovalManager.Models.DTOs;
using Provenance.Services.Data.ApprovalManager.Services;

namespace Provenance.Services.Data.ApprovalManager.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ApprovalController : ControllerBase
    {
        private readonly IApprovalService _approvalService;

        public ApprovalController(IApprovalService approvalService)
        {
            _approvalService = approvalService;
        }

        /// <summary>
        /// Create a new approval request
        /// </summary>
        [HttpPost("requests")]
        public async Task<ActionResult<ApprovalRequestResponseDto>> CreateApprovalRequest([FromBody] CreateApprovalRequestDto request)
        {
            try
            {
                var result = await _approvalService.CreateApprovalRequestAsync(request);
                return CreatedAtAction(nameof(GetApprovalRequest), new { primaryGuid = result.PrimaryGuid }, result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Get a specific approval request by ID
        /// </summary>
        [HttpGet("requests/{primaryGuid}")]
        public async Task<ActionResult<ApprovalRequestResponseDto>> GetApprovalRequest(Guid primaryGuid)
        {
            try
            {
                var result = await _approvalService.GetApprovalRequestAsync(primaryGuid);
                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Get all approval requests with optional filtering
        /// </summary>
        [HttpGet("requests")]
        public async Task<ActionResult<IEnumerable<ApprovalRequestResponseDto>>> GetApprovalRequests(
            [FromQuery] string? requestType = null,
            [FromQuery] ApprovalStatus? status = null,
            [FromQuery] string? requesterId = null)
        {
            try
            {
                var results = await _approvalService.GetApprovalRequestsAsync(requestType, status, requesterId);
                return Ok(results);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Update an approval request
        /// </summary>
        [HttpPut("requests/{primaryGuid}")]
        public async Task<ActionResult<ApprovalRequestResponseDto>> UpdateApprovalRequest(Guid primaryGuid, [FromBody] UpdateApprovalRequestDto request)
        {
            try
            {
                var result = await _approvalService.UpdateApprovalRequestAsync(primaryGuid, request);
                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Delete an approval request
        /// </summary>
        [HttpDelete("requests/{primaryGuid}")]
        public async Task<ActionResult> DeleteApprovalRequest(Guid primaryGuid)
        {
            try
            {
                var result = await _approvalService.DeleteApprovalRequestAsync(primaryGuid);
                if (result)
                    return NoContent();
                else
                    return NotFound(new { error = "Approval request not found" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Approve a request
        /// </summary>
        [HttpPost("requests/{primaryGuid}/approve")]
        public async Task<ActionResult<ApprovalRequestResponseDto>> ApproveRequest(Guid primaryGuid, [FromBody] ApproveRequestDto request)
        {
            try
            {
                var result = await _approvalService.ApproveRequestAsync(primaryGuid, request.ApproverEmail, request.Comments);
                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Reject a request
        /// </summary>
        [HttpPost("requests/{primaryGuid}/reject")]
        public async Task<ActionResult<ApprovalRequestResponseDto>> RejectRequest(Guid primaryGuid, [FromBody] RejectRequestDto request)
        {
            try
            {
                var result = await _approvalService.RejectRequestAsync(primaryGuid, request.RejectorEmail, request.RejectionReason, request.Comments);
                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Add a comment to a request
        /// </summary>
        [HttpPost("requests/{primaryGuid}/comment")]
        public async Task<ActionResult<ApprovalRequestResponseDto>> CommentOnRequest(Guid primaryGuid, [FromBody] CommentRequestDto request)
        {
            try
            {
                var result = await _approvalService.CommentOnRequestAsync(primaryGuid, request.CommenterId, request.Comments);
                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Cancel a request
        /// </summary>
        [HttpPost("requests/{primaryGuid}/cancel")]
        public async Task<ActionResult<ApprovalRequestResponseDto>> CancelRequest(Guid primaryGuid, [FromBody] CancelRequestDto request)
        {
            try
            {
                var result = await _approvalService.CancelRequestAsync(primaryGuid, request.CancellerId, request.Reason);
                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Get pending approvals for a specific user
        /// </summary>
        [HttpGet("users/{userEmail}/pending-approvals")]
        public async Task<ActionResult<IEnumerable<ApprovalRequestResponseDto>>> GetPendingApprovalsForUser(string userEmail)
        {
            try
            {
                var results = await _approvalService.GetPendingApprovalsForUserAsync(userEmail);
                return Ok(results);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Get all requests created by a specific user
        /// </summary>
        [HttpGet("users/{userId}/my-requests")]
        public async Task<ActionResult<IEnumerable<ApprovalRequestResponseDto>>> GetMyRequests(string userId)
        {
            try
            {
                var results = await _approvalService.GetMyRequestsAsync(userId);
                return Ok(results);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
    }

    // DTOs for request bodies
    public class ApproveRequestDto
    {
        public string ApproverEmail { get; set; } = string.Empty;
        public string? Comments { get; set; }
    }

    public class RejectRequestDto
    {
        public string RejectorEmail { get; set; } = string.Empty;
        public string RejectionReason { get; set; } = string.Empty;
        public string? Comments { get; set; }
    }

    public class CommentRequestDto
    {
        public string CommenterId { get; set; } = string.Empty;
        public string Comments { get; set; } = string.Empty;
    }

    public class CancelRequestDto
    {
        public string CancellerId { get; set; } = string.Empty;
        public string? Reason { get; set; }
    }
} 