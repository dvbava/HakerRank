﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Provenance.Services.Data.ApprovalManager.Migrations
{
    /// <inheritdoc />
    public partial class AddGraphQLSupport : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ApprovalRequests",
                columns: table => new
                {
                    PrimaryGuid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    InternalGuid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RequestType = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Title = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                    RequesterId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    RequesterName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    RequesterEmail = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    OriginatingSystem = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Version = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CompletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Comments = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    RejectionReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    ApprovedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    RejectedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ApprovedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RejectedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Metadata = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Priority = table.Column<int>(type: "int", nullable: false),
                    FromDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ToDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApprovalRequests", x => x.PrimaryGuid);
                });

            migrationBuilder.CreateTable(
                name: "SystemConfigurations",
                columns: table => new
                {
                    ConfigurationKey = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ConfigurationValue = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SystemConfigurations", x => x.ConfigurationKey);
                });

            migrationBuilder.CreateTable(
                name: "ApprovalChannels",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ApprovalRequestPrimaryGuid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ChannelType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Status = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ActivatedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CompletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ChannelSpecificData = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApprovalChannels", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApprovalChannels_ApprovalRequests_ApprovalRequestPrimaryGuid",
                        column: x => x.ApprovalRequestPrimaryGuid,
                        principalTable: "ApprovalRequests",
                        principalColumn: "PrimaryGuid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ApprovalRequestApprovers",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ApprovalRequestPrimaryGuid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ApproverEmail = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Status = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ActionedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Comments = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApprovalRequestApprovers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ApprovalRequestApprovers_ApprovalRequests_ApprovalRequestPrimaryGuid",
                        column: x => x.ApprovalRequestPrimaryGuid,
                        principalTable: "ApprovalRequests",
                        principalColumn: "PrimaryGuid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalChannels_ApprovalRequestPrimaryGuid",
                table: "ApprovalChannels",
                column: "ApprovalRequestPrimaryGuid");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalChannels_ChannelType",
                table: "ApprovalChannels",
                column: "ChannelType");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalChannels_Status",
                table: "ApprovalChannels",
                column: "Status");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalRequestApprovers_ApprovalRequestPrimaryGuid",
                table: "ApprovalRequestApprovers",
                column: "ApprovalRequestPrimaryGuid");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalRequestApprovers_ApproverEmail",
                table: "ApprovalRequestApprovers",
                column: "ApproverEmail");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalRequestApprovers_Status",
                table: "ApprovalRequestApprovers",
                column: "Status");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalRequests_CreatedAt",
                table: "ApprovalRequests",
                column: "CreatedAt");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalRequests_OriginatingSystem",
                table: "ApprovalRequests",
                column: "OriginatingSystem");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalRequests_RequesterId",
                table: "ApprovalRequests",
                column: "RequesterId");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalRequests_RequestType",
                table: "ApprovalRequests",
                column: "RequestType");

            migrationBuilder.CreateIndex(
                name: "IX_ApprovalRequests_Status",
                table: "ApprovalRequests",
                column: "Status");

            migrationBuilder.CreateIndex(
                name: "IX_SystemConfigurations_ConfigurationKey",
                table: "SystemConfigurations",
                column: "ConfigurationKey");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ApprovalChannels");

            migrationBuilder.DropTable(
                name: "ApprovalRequestApprovers");

            migrationBuilder.DropTable(
                name: "SystemConfigurations");

            migrationBuilder.DropTable(
                name: "ApprovalRequests");
        }
    }
}
