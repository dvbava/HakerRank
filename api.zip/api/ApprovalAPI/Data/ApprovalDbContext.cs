using Microsoft.EntityFrameworkCore;
using Provenance.Services.Data.ApprovalManager.Models;

namespace Provenance.Services.Data.ApprovalManager.Data
{
    public class ApprovalDbContext : DbContext
    {
        public ApprovalDbContext(DbContextOptions<ApprovalDbContext> options) : base(options)
        {
        }

        public DbSet<ApprovalRequest> ApprovalRequests { get; set; }
        public DbSet<ApprovalRequestApprover> ApprovalRequestApprovers { get; set; }
        public DbSet<ApprovalChannel> ApprovalChannels { get; set; }
        public DbSet<SystemConfiguration> SystemConfigurations { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure ApprovalRequest
            modelBuilder.Entity<ApprovalRequest>(entity =>
            {
                entity.HasKey(e => e.PrimaryGuid);
                entity.Property(e => e.PrimaryGuid).ValueGeneratedOnAdd();
                entity.Property(e => e.RequestType).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Description).HasMaxLength(1000);
                entity.Property(e => e.RequesterId).IsRequired().HasMaxLength(100);
                entity.Property(e => e.RequesterName).HasMaxLength(200);
                entity.Property(e => e.RequesterEmail).HasMaxLength(200);
                entity.Property(e => e.OriginatingSystem).HasMaxLength(100);
                entity.Property(e => e.Version).IsRequired();
                entity.Property(e => e.Comments).HasMaxLength(1000);
                entity.Property(e => e.RejectionReason).HasMaxLength(500);
                entity.Property(e => e.ApprovedBy).HasMaxLength(100);
                entity.Property(e => e.RejectedBy).HasMaxLength(100);
                entity.Property(e => e.Metadata).HasColumnType("nvarchar(max)");
                entity.Property(e => e.Status).HasConversion<string>();
                
                // Indexes for better performance
                entity.HasIndex(e => e.RequestType);
                entity.HasIndex(e => e.Status);
                entity.HasIndex(e => e.RequesterId);
                entity.HasIndex(e => e.OriginatingSystem);
                entity.HasIndex(e => e.CreatedAt);
            });

            // Configure ApprovalRequestApprover
            modelBuilder.Entity<ApprovalRequestApprover>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
                entity.Property(e => e.ApproverEmail).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Status).HasConversion<string>();
                entity.Property(e => e.Comments).HasMaxLength(1000);
                entity.HasOne(e => e.ApprovalRequest)
                      .WithMany(e => e.Approvers)
                      .HasForeignKey(e => e.ApprovalRequestPrimaryGuid)
                      .OnDelete(DeleteBehavior.Cascade);
                entity.HasIndex(e => e.ApprovalRequestPrimaryGuid);
                entity.HasIndex(e => e.ApproverEmail);
                entity.HasIndex(e => e.Status);
            });

            // Configure ApprovalChannel
            modelBuilder.Entity<ApprovalChannel>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
                entity.Property(e => e.ChannelType).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Status).HasConversion<string>();
                entity.Property(e => e.ChannelSpecificData).HasMaxLength(500);
                entity.HasOne(e => e.ApprovalRequest)
                      .WithMany(e => e.Channels)
                      .HasForeignKey(e => e.ApprovalRequestPrimaryGuid)
                      .OnDelete(DeleteBehavior.Cascade);
                entity.HasIndex(e => e.ApprovalRequestPrimaryGuid);
                entity.HasIndex(e => e.ChannelType);
                entity.HasIndex(e => e.Status);
            });

            // Configure SystemConfiguration
            modelBuilder.Entity<SystemConfiguration>(entity =>
            {
                entity.HasKey(e => e.ConfigurationKey);
                entity.Property(e => e.ConfigurationKey).IsRequired().HasMaxLength(100);
                entity.Property(e => e.ConfigurationValue).IsRequired().HasColumnType("nvarchar(max)");
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.HasIndex(e => e.ConfigurationKey);
            });
        }
    }
} 