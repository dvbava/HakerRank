using Xunit;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.InMemory;
using Provenance.Services.Data.ApprovalManager.Services;
using Provenance.Services.Data.ApprovalManager.Data;
using Provenance.Services.Data.ApprovalManager.Models;

namespace ApprovalAPI.Tests.Services
{
    public class ConfigurationServiceTests
    {
        private ApprovalDbContext CreateInMemoryContext()
        {
            var options = new DbContextOptionsBuilder<ApprovalDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;
            return new ApprovalDbContext(options);
        }

        [Fact]
        public async Task GetActiveChannelsAsync_ValidConfiguration_ReturnsChannels()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var configValue = "[{'Id':'12345678-1234-1234-1234-123456789012','ChannelType':'Email','Status':0},{'Id':'87654321-4321-4321-4321-210987654321','ChannelType':'SMS','Status':3}]".Replace('"', '\"').Replace("'", "\"");
            context.SystemConfigurations.Add(new SystemConfiguration
            {
                ConfigurationKey = "ActiveChannels",
                ConfigurationValue = configValue
            });
            await context.SaveChangesAsync();

            var result = await service.GetActiveChannelsAsync();
            result.Should().HaveCount(2);
            result.First().ChannelType.Should().Be("Email");
            result.First().Status.Should().Be(ChannelStatus.Available);
            result.Last().ChannelType.Should().Be("SMS");
            result.Last().Status.Should().Be(ChannelStatus.Disabled);
        }

        [Fact]
        public async Task GetActiveChannelsAsync_MultipleActiveChannels_ReturnsAllActive()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var configValue = "[{'Id':'12345678-1234-1234-1234-123456789012','ChannelType':'Email','Status':0},{'Id':'87654321-4321-4321-4321-210987654321','ChannelType':'SMS','Status':0},{'Id':'11111111-1111-1111-1111-111111111111','ChannelType':'Slack','Status':0}]".Replace('"', '\"').Replace("'", "\"");
            context.SystemConfigurations.Add(new SystemConfiguration
            {
                ConfigurationKey = "ActiveChannels",
                ConfigurationValue = configValue
            });
            await context.SaveChangesAsync();

            var result = await service.GetActiveChannelsAsync();
            result.Should().HaveCount(3);
            result.All(c => c.Status == ChannelStatus.Available).Should().BeTrue();
        }

        [Fact]
        public async Task GetActiveChannelsAsync_NoConfiguration_ReturnsEmptyList()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var result = await service.GetActiveChannelsAsync();
            result.Should().BeEmpty();
        }

        [Fact]
        public async Task GetActiveChannelsAsync_InvalidJson_ReturnsEmptyList()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var configValue = "invalid json";
            context.SystemConfigurations.Add(new SystemConfiguration
            {
                ConfigurationKey = "ActiveChannels",
                ConfigurationValue = configValue
            });
            await context.SaveChangesAsync();

            var result = await service.GetActiveChannelsAsync();
            result.Should().BeEmpty();
        }

        [Fact]
        public async Task SetActiveChannelsAsync_ValidChannels_SavesConfiguration()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var channels = new List<ApprovalChannel>
            {
                new ApprovalChannel { Id = Guid.NewGuid(), ChannelType = "Email", Status = ChannelStatus.Available },
                new ApprovalChannel { Id = Guid.NewGuid(), ChannelType = "SMS", Status = ChannelStatus.Disabled }
            };

            await service.SetActiveChannelsAsync(channels);

            var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == "ActiveChannels");
            result.Should().NotBeNull();
            result.ConfigurationValue.Should().Contain("Email");
            result.ConfigurationValue.Should().Contain("SMS");
        }

        [Fact]
        public async Task SetActiveChannelsAsync_EmptyChannels_SavesEmptyConfiguration()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var channels = new List<ApprovalChannel>();
            await service.SetActiveChannelsAsync(channels);

            var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == "ActiveChannels");
            result.Should().NotBeNull();
            result.ConfigurationValue.Should().Be("[]");
        }

        [Fact]
        public async Task GetConfigurationValueAsync_ValidKey_ReturnsValue()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var configurations = new List<SystemConfiguration>
            {
                new SystemConfiguration
                {
                    ConfigurationKey = "TestKey",
                    ConfigurationValue = "TestValue"
                }
            };
            context.SystemConfigurations.AddRange(configurations);
            await context.SaveChangesAsync();

            var result = await service.GetConfigurationValueAsync("TestKey");
            result.Should().Be("TestValue");
        }

        [Fact]
        public async Task GetConfigurationValueAsync_InvalidKey_ReturnsNull()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var result = await service.GetConfigurationValueAsync("InvalidKey");
            result.Should().BeNull();
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        public async Task GetConfigurationValueAsync_EmptyOrNullKey_ReturnsNull(string key)
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var result = await service.GetConfigurationValueAsync(key);
            result.Should().BeNull();
        }

        [Fact]
        public async Task SetConfigurationValueAsync_NewKey_CreatesConfiguration()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            await service.SetConfigurationValueAsync("NewKey", "NewValue");

            var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == "NewKey");
            result.Should().NotBeNull();
            result.ConfigurationValue.Should().Be("NewValue");
        }

        [Fact]
        public async Task SetConfigurationValueAsync_ExistingKey_UpdatesConfiguration()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var configurations = new List<SystemConfiguration>
            {
                new SystemConfiguration
                {
                    ConfigurationKey = "ExistingKey",
                    ConfigurationValue = "OldValue"
                }
            };
            context.SystemConfigurations.AddRange(configurations);
            await context.SaveChangesAsync();

            await service.SetConfigurationValueAsync("ExistingKey", "NewValue");

            var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == "ExistingKey");
            result.Should().NotBeNull();
            result.ConfigurationValue.Should().Be("NewValue");
        }

        [Fact]
        public async Task SetConfigurationValueAsync_LongKey_SavesSuccessfully()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var longKey = new string('A', 100);
            await service.SetConfigurationValueAsync(longKey, "Value");

            var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == longKey);
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task SetConfigurationValueAsync_LongValue_SavesSuccessfully()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var longValue = new string('B', 1000);
            await service.SetConfigurationValueAsync("Key", longValue);

            var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == "Key");
            result.Should().NotBeNull();
            result.ConfigurationValue.Should().Be(longValue);
        }

        [Fact]
        public async Task SetConfigurationValueAsync_SpecialCharactersInKey_SavesSuccessfully()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var specialKey = "key-with-special-chars_123!@#";
            await service.SetConfigurationValueAsync(specialKey, "Value");

            var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == specialKey);
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task SetConfigurationValueAsync_SpecialCharactersInValue_SavesSuccessfully()
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            var specialValue = "value with special chars: !@#$%^&*()_+-=[]{}|;':\",./<>?";
            await service.SetConfigurationValueAsync("Key", specialValue);

            var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == "Key");
            result.Should().NotBeNull();
            result.ConfigurationValue.Should().Be(specialValue);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        public async Task SetConfigurationValueAsync_EmptyOrNullKey_DoesNotSave(string key)
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            // The service doesn't validate null/empty keys, so we expect it to save
            // but EF Core will throw an exception for null keys
            if (key == null)
            {
                await Assert.ThrowsAsync<InvalidOperationException>(() => 
                    service.SetConfigurationValueAsync(key, "Value"));
            }
            else
            {
                await service.SetConfigurationValueAsync(key, "Value");
                var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == key);
                result.Should().NotBeNull();
            }
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        public async Task SetConfigurationValueAsync_EmptyOrNullValue_DoesNotSave(string value)
        {
            using var context = CreateInMemoryContext();
            var service = new ConfigurationService(context);

            // The service doesn't validate null/empty values, so we expect it to save
            // but EF Core will throw an exception for null values
            if (value == null)
            {
                await Assert.ThrowsAsync<DbUpdateException>(() => 
                    service.SetConfigurationValueAsync("Key", value));
            }
            else
            {
                await service.SetConfigurationValueAsync("Key", value);
                var result = await context.SystemConfigurations.FirstOrDefaultAsync(sc => sc.ConfigurationKey == "Key");
                result.Should().NotBeNull();
                result.ConfigurationValue.Should().Be(value);
            }
        }
    }
} 