using Microsoft.AspNetCore.Mvc;
using Moq;
using FluentAssertions;
using Xunit;
using Provenance.Services.Data.ApprovalManager.Controllers;
using Provenance.Services.Data.ApprovalManager.Models;
using Provenance.Services.Data.ApprovalManager.Services;

namespace ApprovalAPI.Tests.Controllers
{
    public class ConfigurationControllerTests
    {
        private readonly Mock<IConfigurationService> _mockConfigurationService;
        private readonly ConfigurationController _controller;

        public ConfigurationControllerTests()
        {
            _mockConfigurationService = new Mock<IConfigurationService>();
            _controller = new ConfigurationController(_mockConfigurationService.Object);
        }

        [Fact]
        public async Task GetActiveChannels_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            var expectedChannels = new List<ApprovalChannel>
            {
                new() { Id = Guid.NewGuid(), ChannelType = "Email", Status = ChannelStatus.Available },
                new() { Id = Guid.NewGuid(), ChannelType = "SMS", Status = ChannelStatus.Available }
            };

            _mockConfigurationService.Setup(x => x.GetActiveChannelsAsync())
                .ReturnsAsync(expectedChannels);

            // Act
            var result = await _controller.GetActiveChannels();

            // Assert
            var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(expectedChannels);
        }

        [Fact]
        public async Task GetActiveChannels_EmptyList_ReturnsOkResult()
        {
            // Arrange
            var expectedChannels = new List<ApprovalChannel>();

            _mockConfigurationService.Setup(x => x.GetActiveChannelsAsync())
                .ReturnsAsync(expectedChannels);

            // Act
            var result = await _controller.GetActiveChannels();

            // Assert
            var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(expectedChannels);
        }

        [Fact]
        public async Task GetActiveChannels_ServiceThrowsException_ReturnsBadRequest()
        {
            // Arrange
            _mockConfigurationService.Setup(x => x.GetActiveChannelsAsync())
                .ThrowsAsync(new Exception("Service error"));

            // Act
            var result = await _controller.GetActiveChannels();

            // Assert
            result.Result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task SetActiveChannels_ValidChannels_ReturnsOkResult()
        {
            // Arrange
            var channels = new List<ApprovalChannel>
            {
                new() { Id = Guid.NewGuid(), ChannelType = "Email", Status = ChannelStatus.Available },
                new() { Id = Guid.NewGuid(), ChannelType = "SMS", Status = ChannelStatus.Disabled }
            };

            _mockConfigurationService.Setup(x => x.SetActiveChannelsAsync(channels))
                .Returns(Task.CompletedTask);

            // Act
            var result = await _controller.SetActiveChannels(channels);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(new { message = "Active channels updated successfully" });
        }

        [Fact]
        public async Task SetActiveChannels_NullChannels_ReturnsBadRequest()
        {
            // Arrange
            _mockConfigurationService.Setup(x => x.SetActiveChannelsAsync(null!))
                .ThrowsAsync(new ArgumentNullException("channels"));

            // Act
            var result = await _controller.SetActiveChannels(null!);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task SetActiveChannels_EmptyChannels_ReturnsOkResult()
        {
            // Arrange
            var channels = new List<ApprovalChannel>();

            _mockConfigurationService.Setup(x => x.SetActiveChannelsAsync(channels))
                .Returns(Task.CompletedTask);

            // Act
            var result = await _controller.SetActiveChannels(channels);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(new { message = "Active channels updated successfully" });
        }

        [Fact]
        public async Task SetActiveChannels_ServiceThrowsException_ReturnsBadRequest()
        {
            // Arrange
            var channels = new List<ApprovalChannel>();
            _mockConfigurationService.Setup(x => x.SetActiveChannelsAsync(channels))
                .ThrowsAsync(new Exception("Service error"));

            // Act
            var result = await _controller.SetActiveChannels(channels);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task GetConfigurationValue_ValidKey_ReturnsOkResult()
        {
            // Arrange
            var key = "testKey";
            var expectedValue = "testValue";

            _mockConfigurationService.Setup(x => x.GetConfigurationValueAsync(key))
                .ReturnsAsync(expectedValue);

            // Act
            var result = await _controller.GetConfigurationValue(key);

            // Assert
            var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(new { key, value = expectedValue });
        }

        [Fact]
        public async Task GetConfigurationValue_KeyNotFound_ReturnsNotFound()
        {
            // Arrange
            var key = "nonexistentKey";

            _mockConfigurationService.Setup(x => x.GetConfigurationValueAsync(key))
                .ReturnsAsync((string?)null);

            // Act
            var result = await _controller.GetConfigurationValue(key);

            // Assert
            result.Result.Should().BeOfType<NotFoundObjectResult>();
        }

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        public async Task GetConfigurationValue_EmptyOrNullKey_ReturnsBadRequest(string key)
        {
            // Arrange
            _mockConfigurationService.Setup(x => x.GetConfigurationValueAsync(key))
                .ThrowsAsync(new ArgumentException("Key cannot be empty"));

            // Act
            var result = await _controller.GetConfigurationValue(key);

            // Assert
            result.Result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task GetConfigurationValue_ServiceThrowsException_ReturnsBadRequest()
        {
            // Arrange
            var key = "testKey";
            _mockConfigurationService.Setup(x => x.GetConfigurationValueAsync(key))
                .ThrowsAsync(new Exception("Service error"));

            // Act
            var result = await _controller.GetConfigurationValue(key);

            // Assert
            result.Result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task SetConfigurationValue_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            var key = "testKey";
            var request = new SetConfigurationRequest
            {
                Value = "testValue",
                Description = "Test description"
            };

            _mockConfigurationService.Setup(x => x.SetConfigurationValueAsync(key, request.Value, request.Description))
                .Returns(Task.CompletedTask);

            // Act
            var result = await _controller.SetConfigurationValue(key, request);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(new { message = $"Configuration key '{key}' updated successfully" });
        }

        [Fact]
        public async Task SetConfigurationValue_WithoutDescription_ReturnsOkResult()
        {
            // Arrange
            var key = "testKey";
            var request = new SetConfigurationRequest
            {
                Value = "testValue"
            };

            _mockConfigurationService.Setup(x => x.SetConfigurationValueAsync(key, request.Value, request.Description))
                .Returns(Task.CompletedTask);

            // Act
            var result = await _controller.SetConfigurationValue(key, request);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(new { message = $"Configuration key '{key}' updated successfully" });
        }

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        public async Task SetConfigurationValue_EmptyOrNullKey_ReturnsBadRequest(string key)
        {
            // Arrange
            var request = new SetConfigurationRequest { Value = "testValue" };
            _mockConfigurationService.Setup(x => x.SetConfigurationValueAsync(key, request.Value, request.Description))
                .ThrowsAsync(new ArgumentException("Key cannot be empty"));

            // Act
            var result = await _controller.SetConfigurationValue(key, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task SetConfigurationValue_NullRequest_ReturnsBadRequest()
        {
            // Arrange
            var key = "testKey";

            // Act
            var result = await _controller.SetConfigurationValue(key, null!);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task SetConfigurationValue_EmptyValue_ReturnsBadRequest()
        {
            // Arrange
            var key = "testKey";
            var request = new SetConfigurationRequest { Value = "" };
            _mockConfigurationService.Setup(x => x.SetConfigurationValueAsync(key, request.Value, request.Description))
                .ThrowsAsync(new ArgumentException("Value cannot be empty"));

            // Act
            var result = await _controller.SetConfigurationValue(key, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task SetConfigurationValue_ServiceThrowsException_ReturnsBadRequest()
        {
            // Arrange
            var key = "testKey";
            var request = new SetConfigurationRequest { Value = "testValue" };
            _mockConfigurationService.Setup(x => x.SetConfigurationValueAsync(key, request.Value, request.Description))
                .ThrowsAsync(new Exception("Service error"));

            // Act
            var result = await _controller.SetConfigurationValue(key, request);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task SetConfigurationValue_LongKey_ReturnsOkResult()
        {
            // Arrange
            var key = new string('a', 1000); // Very long key
            var request = new SetConfigurationRequest { Value = "testValue" };

            _mockConfigurationService.Setup(x => x.SetConfigurationValueAsync(key, request.Value, request.Description))
                .Returns(Task.CompletedTask);

            // Act
            var result = await _controller.SetConfigurationValue(key, request);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(new { message = $"Configuration key '{key}' updated successfully" });
        }

        [Fact]
        public async Task SetConfigurationValue_LongValue_ReturnsOkResult()
        {
            // Arrange
            var key = "testKey";
            var request = new SetConfigurationRequest { Value = new string('v', 10000) }; // Very long value

            _mockConfigurationService.Setup(x => x.SetConfigurationValueAsync(key, request.Value, request.Description))
                .Returns(Task.CompletedTask);

            // Act
            var result = await _controller.SetConfigurationValue(key, request);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(new { message = $"Configuration key '{key}' updated successfully" });
        }

        [Fact]
        public async Task GetConfigurationValue_SpecialCharactersInKey_ReturnsOkResult()
        {
            // Arrange
            var key = "test-key_with.special@characters#123";
            var expectedValue = "testValue";

            _mockConfigurationService.Setup(x => x.GetConfigurationValueAsync(key))
                .ReturnsAsync(expectedValue);

            // Act
            var result = await _controller.GetConfigurationValue(key);

            // Assert
            var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
            okResult.Value.Should().BeEquivalentTo(new { key, value = expectedValue });
        }

        [Fact]
        public async Task SetActiveChannels_InvalidChannelData_ReturnsBadRequest()
        {
            // Arrange
            var channels = new List<ApprovalChannel>
            {
                new() { Id = Guid.Empty, ChannelType = "", Status = ChannelStatus.Available } // Invalid data
            };

            _mockConfigurationService.Setup(x => x.SetActiveChannelsAsync(channels))
                .ThrowsAsync(new ArgumentException("Invalid channel data"));

            // Act
            var result = await _controller.SetActiveChannels(channels);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }
    }
} 