# ApprovalAPI Unit Tests

This project contains comprehensive unit tests for the ApprovalAPI application using XUnit, Moq, and FluentAssertions.

## Test Structure

### Controllers
- **ApprovalControllerTests.cs** - Tests for the ApprovalController
  - Tests all CRUD operations for approval requests
  - Tests approval workflow (approve, reject, comment, cancel)
  - Tests edge cases like null inputs, invalid GUIDs, and service exceptions
  - Tests filtering and user-specific queries

- **ConfigurationControllerTests.cs** - Tests for the ConfigurationController
  - Tests active channels configuration management
  - Tests configuration key-value operations
  - Tests edge cases like empty/null values and special characters

### Services
- **ApprovalServiceTests.cs** - Tests for the ApprovalService
  - Tests business logic for approval request management
  - Tests integration with email service and configuration service
  - Tests database operations with mocked DbContext
  - Tests error handling and edge cases

- **ConfigurationServiceTests.cs** - Tests for the ConfigurationService
  - Tests configuration storage and retrieval
  - Tests JSON serialization/deserialization of channel configurations
  - Tests database operations with mocked DbContext
  - Tests edge cases like invalid JSON and empty configurations

- **EmailServiceTests.cs** - Tests for the EmailService
  - Tests email sending functionality
  - Tests various email formats and content types
  - Tests SMTP configuration handling
  - Tests error handling for network and authentication issues

## Test Coverage

The tests cover the following scenarios:

### Happy Path Scenarios
- Valid input processing
- Successful database operations
- Proper response formatting
- Correct status code returns

### Edge Cases
- Null and empty inputs
- Invalid GUIDs and IDs
- Malformed JSON data
- Special characters in inputs
- Very long strings and data
- Unicode and international characters

### Error Scenarios
- Service exceptions
- Database connection failures
- Network timeouts
- Authentication failures
- Invalid configuration
- Missing data scenarios

### Integration Scenarios
- Service-to-service communication
- Database transaction handling
- Email notification sending
- Configuration management

## Running Tests

### Prerequisites
- .NET 8.0 SDK
- PowerShell (for running the test script)

### Using the Test Script
```powershell
# Run all tests with coverage
.\run-tests.ps1
```

### Using dotnet CLI
```bash
# Navigate to test project
cd ApprovalAPI.Tests

# Run all tests
dotnet test

# Run tests with coverage
dotnet test --collect:"XPlat Code Coverage"

# Run specific test class
dotnet test --filter "FullyQualifiedName~ApprovalControllerTests"

# Run tests with detailed output
dotnet test --logger "console;verbosity=detailed"
```

### Using Visual Studio
1. Open the solution in Visual Studio
2. Open Test Explorer (Test > Test Explorer)
3. Run all tests or specific test methods

## Test Dependencies

The tests use the following NuGet packages:

- **XUnit** - Testing framework
- **Moq** - Mocking framework for dependencies
- **FluentAssertions** - More readable assertions
- **Microsoft.AspNetCore.Mvc.Testing** - ASP.NET Core testing utilities
- **coverlet.collector** - Code coverage collection

## Mocking Strategy

### Database Context
- Uses Moq to mock `ApprovalDbContext`
- Mocks `DbSet<T>` for each entity type
- Simulates LINQ queries and database operations

### External Services
- Mocks `IEmailService` to avoid actual email sending
- Mocks `IConfigurationService` for configuration operations
- Mocks `IOptions<SmtpSettings>` for SMTP configuration

### HTTP Context
- Uses `Microsoft.AspNetCore.Mvc.Testing` for controller testing
- Tests HTTP status codes and response formats
- Validates action results and model binding

## Test Data

Tests use realistic but safe test data:
- Valid GUIDs for entity IDs
- Realistic email addresses and names
- Proper JSON structures for configuration
- Meaningful test descriptions and comments

## Best Practices Followed

1. **Arrange-Act-Assert Pattern** - Clear test structure
2. **Descriptive Test Names** - Easy to understand what's being tested
3. **Single Responsibility** - Each test focuses on one scenario
4. **Proper Setup/Teardown** - Clean test environment
5. **Edge Case Coverage** - Tests boundary conditions
6. **Error Handling** - Tests exception scenarios
7. **Mocking** - Isolates units under test
8. **Async/Await** - Proper async test handling

## Coverage Goals

The tests aim to achieve:
- **Line Coverage**: >90%
- **Branch Coverage**: >85%
- **Method Coverage**: >95%

## Continuous Integration

These tests are designed to run in CI/CD pipelines:
- Fast execution (< 30 seconds for full suite)
- No external dependencies
- Deterministic results
- Clear pass/fail indicators

## Troubleshooting

### Common Issues

1. **Test Failures Due to Missing Dependencies**
   - Ensure all NuGet packages are restored
   - Run `dotnet restore` before testing

2. **Mock Setup Issues**
   - Check that all dependencies are properly mocked
   - Verify mock setup matches actual service calls

3. **Database Context Issues**
   - Ensure DbSet mocks are properly configured
   - Check LINQ query mocking setup

4. **Async Test Issues**
   - Use `await` for async operations
   - Don't use `.Result` in async tests

### Debugging Tests

1. **Run Individual Tests**
   ```bash
   dotnet test --filter "FullyQualifiedName~SpecificTestName"
   ```

2. **Enable Detailed Logging**
   ```bash
   dotnet test --logger "console;verbosity=detailed"
   ```

3. **Use Debug Configuration**
   ```bash
   dotnet test --configuration Debug
   ```

## Contributing

When adding new tests:

1. Follow the existing naming conventions
2. Use the Arrange-Act-Assert pattern
3. Include edge cases and error scenarios
4. Mock external dependencies
5. Write descriptive test names
6. Add comments for complex test logic
7. Ensure tests are fast and reliable

## Maintenance

- Update tests when service interfaces change
- Add tests for new features
- Refactor tests when business logic changes
- Monitor test execution time
- Review and update test data as needed 